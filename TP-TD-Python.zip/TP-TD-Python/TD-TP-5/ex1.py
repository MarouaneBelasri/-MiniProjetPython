import numpy as np
#Q1
tab = np.arange(10)
#tab = np.array([0,1,2,3,4,5,6,7,8,9])
print(tab)

tab_aleatoire = np.random.random((3,3))
print(tab_aleatoire)

tab_3d = np.zeros((2,3,4))
print(tab_3d)
#Q2
print("troisième élément du tableau 1D",tab[2])
print("la deuxième ligne et première colonne du tableau 2D",tab_aleatoire[1,0])
tab_3d[1,2,3] = 7
print("tableau 3D apres la modification",tab_3d)
#Q3
print("les trois premiers éléments du tableau 1D",tab[0:3])
print("la dernière colonne du tableau 2D",tab_aleatoire[0:3,2])#[:,2]


