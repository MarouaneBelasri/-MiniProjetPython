import numpy as np
#q1 Création du tableau des ventes mensuelles (valeurs aléatoires entre 100 et 1000)
np.random.seed(42)  # Pour reproductibilité
ventes = np.random.randint(100, 1001, size=(12, 3))
mois = np.array(["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Août", "Sep", "Oct", "Nov", "Déc"])
print("Tableau des ventes (P1, P2, P3) :\n", ventes)
#q2 Total des ventes annuelles pour chaque produit
totaux_produits = np.sum(ventes, axis=0)
print("\nTotal des ventes annuelles pour chaque produit :")
for i, total in enumerate(totaux_produits, start=1):
    print(f"P{i} : {total}")
#q3 Moyenne des ventes mensuelles pour chaque produit
moyennes_produits = np.mean(ventes, axis=0)
print("\nMoyenne mensuelle des ventes :")
for i, moyenne in enumerate(moyennes_produits, start=1):
    print(f"P{i} : {moyenne:.2f}")
#q4 Mois avec ventes maximales pour chaque produit
max_indices = np.argmax(ventes, axis=0)
print("\nMois avec les ventes maximales pour chaque produit :")
for i, idx in enumerate(max_indices, start=1):
    print(f"P{i} : {mois[idx]} ({ventes[idx, i-1]})")
#q5 Croissance mensuelle en pourcentage
croissance = np.diff(ventes, axis=0) / ventes[:-1] * 100
print("\nCroissance mensuelle en pourcentage (approximative) :\n", croissance.round(2))
#q6 Mois avec la plus forte croissance pour chaque produit
croissance_max_idx = np.argmax(croissance, axis=0) + 1  # +1 car np.diff réduit la dimension
print("\nMois avec la plus forte croissance pour chaque produit :")
for i, idx in enumerate(croissance_max_idx, start=1):
    print(f"P{i} : {mois[idx]} (Croissance de {croissance[idx - 1, i - 1]:.2f}%)")
#q7 Somme des ventes totales par mois (tous produits confondus)
somme_par_mois = np.sum(ventes, axis=1)
print("\nSomme des ventes par mois (tous produits) :\n", somme_par_mois)

