import numpy as np
tab_1 = np.arange(12)
print(tab_1)
tab_2 = tab_1.reshape(3,4)
print(tab_2)
print(tab_1.shape)
print(tab_2.shape)
tab_3 = tab_1.reshape(2,2,3)
print(tab_3.shape)
print("tab 3D : \n",tab_3)
#Q2
print("transposer :\n",tab_2.T)
tab_4 = np.swapaxes(tab_2,0,1)
print("transposer par swapaxes :\n",tab_4)
#Q3
tab_5 = np.arange(6)
arr_1 = tab_5.reshape(2,3)
arr_2 = tab_5.reshape(2,3)
arr_3 = np.vstack((arr_1,arr_2))
arr_4 = np.hstack((arr_1,arr_2))
print("verticalement : \n",arr_3)
print("horizontalement : \n",arr_4)
arr_5 = np.split(arr_3,2)
print(arr_5)


