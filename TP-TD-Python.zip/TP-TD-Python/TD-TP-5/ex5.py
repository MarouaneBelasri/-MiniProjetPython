import numpy as np
import matplotlib.pyplot as plt
#q1 Crée un tableau de données (100, 3) avec des variables aléatoires et calcule la matrice de covariance
data = np.random.randn(100, 3)
cov_matrix = np.cov(data, rowvar=False)
print("Matrice de covariance :\n", cov_matrix)
#q2 Applique la transformation de Fourier sur un signal sinusoïdal
t = np.linspace(0, 1, 500, endpoint=False)
signal = np.sin(2 * np.pi * 50 * t) + np.sin(2 * np.pi * 80 * t)
fft_result = np.fft.fft(signal)
frequencies = np.fft.fftfreq(len(signal), d=t[1] - t[0])
magnitude = np.abs(fft_result)
plt.figure(figsize=(10, 4))
plt.plot(frequencies[:len(frequencies)//2], magnitude[:len(magnitude)//2])
plt.title("Spectre de fréquences")
plt.xlabel("Fréquence (Hz)")
plt.ylabel("Amplitude")
plt.grid()
plt.tight_layout()
plt.show()
#q3 Simule 1000 lancers de deux dés et affiche l'histogramme des sommes
dice1 = np.random.randint(1, 7, 1000)
dice2 = np.random.randint(1, 7, 1000)
sums = dice1 + dice2
plt.figure(figsize=(6, 4))
plt.hist(sums, bins=np.arange(2, 14) - 0.5, edgecolor='black', density=True)
plt.title("Histogramme des sommes de deux dés (1000 lancers)")
plt.xlabel("Somme")
plt.ylabel("Fréquence relative")
plt.xticks(range(2, 13))
plt.grid(True)
plt.tight_layout()
plt.show()

