import numpy as np
np.random.seed(0)
tab1 = np.random.randint(0,100,size=(5,5))
print(tab1)
print("statistiques par ligne : ")
print("la moyenne  : ",np.mean(tab1,axis=1))
print("l'ecart type : ",np.std(tab1,axis=1))
print("le minimum : ",np.min(tab1,axis=1))
print("le maximum : ",np.max(tab1,axis=1))
print("statistiques par colonne : ")
print("la moyenne  : ",np.mean(tab1,axis=0))
print("l'ecart type : ",np.std(tab1,axis=0))
print("le minimum : ",np.min(tab1,axis=0))
print("le maximum : ",np.max(tab1,axis=0))
print("_________________________________________________________________________________________")
#q2
tab2 = np.random.randint(0,50,10)
print(tab2)
tab2_trier = np.sort(tab2)
print(tab2_trier)
indice_max = np.argmax(tab2_trier)
print("l'indice du maximun dans le tableau trie : ",indice_max)
print("__________________________________________________________________________________________")
#q3
tab3 = np.array([1,2,3,4])
tab4 = np.random.randint(1,10,size=(3,4))
tab5 = tab3 * tab4
print(tab3)
print(tab4)
print(tab5)


