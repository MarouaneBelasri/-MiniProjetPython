import numpy as np
import math
#Q1
tab_1 = np.array([1,2,3,4,5])
tab_2 = np.array([6,7,8,9,10])
print(tab_1)
print(tab_2)
tab_add = tab_1 + tab_2
print(tab_add)
tab_sous = tab_1 - tab_2
print(tab_sous)
tab_multip = tab_1 * tab_2
print(tab_multip)
tab_div = tab_1 / tab_2
print(tab_div)
#Q2
tab_3 = np.linspace(0,math.pi,5)
print(tab_3)
print("sin de chaque elem de tableau : ",np.sin(tab_3))
print("cos de chaque elem de tableau : ",np.cos(tab_3))
print("exp de chaque elem de tableau : ",np.exp(tab_3))
#Q3
tab_4 = np.arange(10,dtype=int)
print(tab_4)
print(f"l'elems pairs :{tab_4[tab_4%2==0]} ")
tab_4[tab_4%2!=0] = -1
print(tab_4)
