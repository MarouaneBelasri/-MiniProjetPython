#Q1
matieres = ["anglais","physique","maths","svt"]
print(matieres)
#Q2
matieres.append("histoire")
matieres.append("geograqhie")
print(matieres)
#Q3
print(matieres[:4]) # afficher les 4 premiers elements de la liste
print(matieres[3:]) # afficher les 3 derniers elements de la liste
print(matieres[1:4]) # afficher 3 elements depuis le second indice

