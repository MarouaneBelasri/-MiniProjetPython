#Q1
mylist = ["apple","banana","cherry"]
print(mylist[1]) # affichage => "banane"
#Q2
mylist = ["apple","banana","banana","cherry"]
print(mylist[2]) # affichage => "banane" la troisieme element de la liste
#Q3
thislist = ["apple","banana","cherry"]
print(len(thislist)) #retourne la taille de la liste
#Q4
mylist = ["apple","banana","cherry"]
print(mylist[-1]) # affichage => "cherry" la derniere element de la liste
#Q5
fruits = ["apple","banana","cherry"]
print(mylist[1]) # affichage de  la second element de la liste
#Q6
mylist = ["apple","banana","cherry","orange","kiwi"]
print(mylist[1:4]) # affichage => ["banane" ,"cherry","orange"]
#Q7
fruits = ["apple","banana","cherry","orange","kiwi","melon","mango"]
print(fruits[2:5]) # afficher le 3,4 et 5 element de la liste