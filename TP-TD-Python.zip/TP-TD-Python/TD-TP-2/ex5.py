#Q1 utiliser la methode remove pour supprimer la valeur mer
semaine = ["lun","mar","mer","jau","ven","sam","dim"]
semaine.remove("mer")
print(semaine)
#Q2
mylist = ["apple","banana","cherry"]
mylist.pop(1) # supprimer l'element de l'indice 1 (second element dans la liste "banana")
print(mylist)
#Q3 la fonction qui permet de vider la liste
fruits = ["apple","banana","cherry"]
fruits.clear()
print(fruits)
