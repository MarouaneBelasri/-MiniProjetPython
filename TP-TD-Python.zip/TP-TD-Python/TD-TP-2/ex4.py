#Q1
mylist = ["apple","banana","cherry"]
mylist[0] = "kiwi"
print(mylist[1])
#Q2 modifiez la valeur de apple a kiwi dans la liste fruits
fruits = ["apple","banana","cherry"]
mylist[0] = "kiwi"
print(mylist)
#Q3
mylist = ["apple","banana","cherry"]
mylist[1:2] = ["kiwi","mango"]
print(mylist[2])
#Q4
mylist = ["apple","banana","cherry"]
mylist.insert(0,'mango')
print(mylist[1])
#Q5 ajouter via la fonction append la valeur 'orange'
mylist = ["apple","banana","cherry"]
mylist.append("orange")
print(mylist)
#Q6 utiliser la fonction insert pour ajouter a la second position 'lemon'
mylist = ["apple","banana","cherry"]
mylist.insert(1,"lemon")
print(mylist)
