#Q1
semaine = ["lundi","mardi","mercredi","jeudi","vendredi","samedi","dimanche"]
print(semaine)
#Q2
couleur=[]
for i in range(7):
    couleur.append(input("enter un couleur : "))
print(couleur)
#Q3
reels = [1,2,3,4,5,6,7]
for i in range(len(reels)):
    if i%2 != 0 :
        print(reels[i])