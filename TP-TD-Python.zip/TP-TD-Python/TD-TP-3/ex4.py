def element_existe(liste, element):
     existe = element in liste
     return existe

nombres = [10, 15, 20, 25, 30]
print("L'élément 15 est dans la liste:", element_existe(nombres, 15))
print("L'élément 50 est dans la liste:", element_existe(nombres, 50))


