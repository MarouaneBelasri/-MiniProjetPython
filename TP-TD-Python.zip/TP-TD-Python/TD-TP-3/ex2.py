mylist = [4, 8, 15, 16, 23, 42]
def somme_liste(liste):
    return sum(liste)
def moyenne_liste(liste):
    return sum(liste)/len(liste)

print(f"la somme des elements de la liste est {somme_liste(mylist)}")
print(f"la moyenne des elements de la liste est {moyenne_liste(mylist)}")

