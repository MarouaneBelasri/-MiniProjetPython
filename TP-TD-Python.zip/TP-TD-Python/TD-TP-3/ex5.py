def liste_carres(liste):
    carr = [x**2 for x in liste]
    return carr

nombres = [2, 15, 20, 25, 30]
carres = liste_carres(nombres)
print("Liste des carrés:",carres)

