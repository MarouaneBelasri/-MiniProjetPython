def trouver_min_max(liste):
    if not liste:
        return None
    return (min(liste), max(liste))

nombres = [10, 15, 20, 25, 30]
min_max = trouver_min_max(nombres)
print("Minimum et maximum de la liste:",min_max)


