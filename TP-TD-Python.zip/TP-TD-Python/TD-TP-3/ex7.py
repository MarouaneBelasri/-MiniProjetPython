autres_nombres = [7, 11, 19, 24, 33]

def fusionner_et_trier(liste1, liste2):
    return sorted(liste1 + liste2)

nombres = [10, 15, 20, 25, 30]
# Tester la fonction
fusion_resultat = fusionner_et_trier(nombres, autres_nombres)
# Afficher les résultats
print("Liste fusionnée et triée:", fusion_resultat)


