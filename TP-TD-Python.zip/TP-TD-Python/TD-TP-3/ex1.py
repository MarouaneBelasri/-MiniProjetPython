mylist = [4, 8, 15, 16, 23, 42]
def affListe(list):
    for i in list:
        print(i)

affListe(mylist)
