def extraire_pairs(liste):
    list_paire = []
    for i in liste:
        if i % 2 == 0:
            list_paire.append(i)
    return list_paire

mylist = [4, 8, 15, 16, 23, 42]
pairs = extraire_pairs(mylist)
for i in pairs:
    print(i)

