import math

rayon = float(input("entez le rayon : "))
hauteur = float(input("entez le hauteur : "))
volume = (1/3)*(math.pi*rayon*rayon*hauteur)
print("le volume d'un cone est : ",volume)