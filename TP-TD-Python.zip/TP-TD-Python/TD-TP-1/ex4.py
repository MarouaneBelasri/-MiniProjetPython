import math

Rg = float(input("entez le rayon de disque principale : "))
Rp = float(input("entez le rayon de trou : "))
surface_principale = math.pi*(Rg**2)
surface_trou = math.pi*(Rp**2)
surface_decoupee = surface_principale - surface_trou
print("la surface du disque decoupee : ",surface_decoupee)


