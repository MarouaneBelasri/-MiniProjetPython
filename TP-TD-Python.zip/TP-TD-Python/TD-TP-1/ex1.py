nom =  "marouane"
age = 22
note = 18.5
print(type(nom))
print(type(age))
print(type(note))
str1,int1,dec1 = ("bonjour",13,14.75)
print(int1)
#q2
nom,prenom,age = ("belasri","marouane",22)
print(f"my full name is {prenom} {nom} , im {age} years old ")