phrase = input("saisir une phrase : ")
longueur = len(phrase)

if longueur%2 == 0 :
    print(f"la longueur le la phrase est paire : {longueur}")
    print(f"la phrase : {phrase[:int(longueur/2)]}")
else:
    print(f"la longueur le la phrase est impaire : {longueur}")
    print(f"la phrase : {phrase[int(longueur / 2):]}")