#q1
noteMath = float(input("saisir note  mathématique : "))
notePC = float(input("saisir note  physique : "))
noteAnglais = float(input("saisir note anglais : "))
noteSVT = float(input("saisir note svt : "))

coeffMath = int(input("saisir coefficient  mathématique : "))
coeffPC = int(input("saisir coefficient  physique : "))
coeffAnglais = int(input("saisir coefficient anglais : "))
coeffSVT = int(input("saisir coefficient svt : "))
sommeCoeff = coeffAnglais+coeffPC+coeffSVT+coeffMath
somme = noteMath*coeffMath + notePC*coeffPC + noteSVT*coeffSVT + noteAnglais*coeffAnglais
moyenne = somme/sommeCoeff
print(f"la moyenne des notes est : {moyenne}")
#Q2
budget = float(input("entrez votre budget : "))
achats = float(input("entrez le montant des achats : "))
if budget >= achats :
    print("votre budget est suffisant")
else:
    print("votre budget est insuffisant")